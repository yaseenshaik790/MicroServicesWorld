package com.sky.activeprofile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsActiveprofileApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsActiveprofileApplication.class, args);
	}

}
